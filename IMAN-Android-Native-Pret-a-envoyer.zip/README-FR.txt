IMAN — Projet Android avec compilation automatique

Le projet conserve le fichier HTML dans app/src/main/assets/index.html.
Le HTML/CSS/JavaScript n'est pas reconstruit par le workflow.

COMPILATION AUTOMATIQUE DEPUIS UN TELEPHONE
Consulter DEMARRER-DEPUIS-TELEPHONE.txt. Le workflow GitHub Actions se trouve dans
.github/workflows/build-apk.yml. Apres envoi des fichiers dans un depot GitHub, il compile
un APK debug et le publie comme artefact telechargeable pendant 14 jours.

COMPILATION LOCALE
Android Studio, JDK 17, Android SDK Platform 35 et Gradle 8.9 sont requis.
Commande : gradle :app:assembleDebug
Sortie : app/build/outputs/apk/debug/app-debug.apk

NOTES
- Il s'agit d'une application Android utilisant WebView pour afficher le HTML local.
- Certaines ressources externes (par exemple Google Fonts) peuvent necessiter Internet.
- L'APK debug est destine aux essais personnels, pas a une publication directe sur Play Store.
- Tester l'application sur le telephone et verifier les fonctionnalites avant toute diffusion.
